public class Main {
    public static void main(String[] args) {

        System.out.println(suma(5,10,15));
            }

    public static int suma (int a, int b, int c){
        int resultado= a+b+c;
        return resultado;
    }
}